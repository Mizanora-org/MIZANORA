import { NextResponse } from 'next/server';
import { denyIf } from '@/lib/siteGate';
import { adminDb, adminReady } from '@/lib/firebase-admin';
import { findWorkerByCode } from '@/lib/workerAuth';
import { cleanWorkerCode } from '@/lib/workers';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// Tells the shop whether a ref code is valid and which own prices and market rates to show. Nothing private is returned.
export async function GET(req) {
  const closed = await denyIf('workers');
  if (closed) return closed;
  const code = cleanWorkerCode(new URL(req.url).searchParams.get('code'));
  if (!code || !adminReady()) return NextResponse.json({ ok: false });
  try {
    const w = await findWorkerByCode(adminDb(), code);
    if (!w) return NextResponse.json({ ok: false, invalid: true });
    return NextResponse.json({ ok: true, markups: w.markups || {}, market: w.market || {} }, { headers: { 'Cache-Control': 'private, max-age=60' } });
  } catch { return NextResponse.json({ ok: false }); }
}
