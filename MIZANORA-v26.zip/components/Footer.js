import Link from 'next/link';
import { SITE } from '@/lib/config';
import { CREDIT, FOUNDER, FOUNDER_LINKS } from '@/lib/team';
import { SOCIAL_ICONS } from './Icons';
import FxToggle from './FxToggle';
import InstallApp from './InstallApp';

export default function Footer({ categories = [] }) {
  const socials = SITE.social.filter((s) => s.url);
  return (
    <footer className="no-print mt-16 bg-surface pb-28 md:pb-10">
      <div className="mz-band" aria-hidden="true" />
      <p lang="ar" dir="rtl" className="font-arabic pt-6 text-center text-2xl text-gold">بِسْمِ اللَّهِ تَوَكَّلْنَا عَلَى اللَّهِ</p>
      <p className="text-center text-xs text-faint">Jazakallah khair for shopping with Mizanora</p>
      <FxToggle />
      <div className="mb-8" />
      <div className="mx-auto grid max-w-7xl gap-8 border-t border-line px-4 pt-10 sm:grid-cols-2 lg:grid-cols-5">
        <div className="lg:col-span-2">
          <p className="font-display text-2xl font-bold tracking-[0.14em]">MIZANORA</p>
          <p className="mt-3 max-w-sm text-sm text-dim">{SITE.tagline} A Pakistani online store built on honest dealing. Cash on delivery across Pakistan. WhatsApp support is always here to help.</p>
          <p className="mt-3 max-w-sm rounded-xl border border-line bg-raised p-3 text-sm text-dim">
            <b className="text-cream">{FOUNDER.name}</b> — <b className="text-gold">{FOUNDER.role}</b>
            <span className="mt-1 block text-xs">Mizanora ka pura web app, assistant Noor aur worker programme inhi ne banaya.</span>
            <Link href="/team" className="mt-1.5 inline-block text-xs font-bold text-gold underline underline-offset-4">Team &amp; public profiles</Link>
            <span className="mt-1.5 flex flex-wrap gap-x-3 gap-y-1 text-xs font-bold">{FOUNDER_LINKS.slice(0, 3).map(([l, u]) => <a key={u} href={u} target="_blank" rel="noopener noreferrer me" className="text-gold underline underline-offset-4">{l}</a>)}</span>
          </p>
          <div className="mt-4 flex gap-3">
            {socials.map((s) => {
              const Icon = SOCIAL_ICONS[s.id];
              return <a key={s.id} href={s.url} target="_blank" rel="noopener noreferrer" aria-label={s.label} className="grid h-10 w-10 place-items-center rounded-full bg-raised text-gold hover:bg-line"><Icon size={20} /></a>;
            })}
          </div>
        </div>
        <FooterCol title="Shop" links={[['/deals', 'Deals'], ['/products', 'All products'], ...categories.slice(0, 5).map((c) => [`/category/${c.slug}`, c.name]), ['/cart', 'Cart']]} />
        <FooterCol title="Help" links={[['/workers', 'Earn with Mizanora'], ['/reels', 'Reels'], ['/account', 'My account'], ['/track', 'Track order'], ['/wishlist', 'Wishlist'], ['/how-to-order', 'How to order'], ['/faq', 'FAQ'], ['/returns', 'Returns'], ['/contact', 'Contact support'], ['/connect', 'Official accounts']]} />
        <div>
          <FooterCol title="Company" links={[['/about', 'About us'], ['/team', 'Team & profiles'], ['/muaaz-iqbal', 'Muaaz Iqbal'], ['/quran', 'Quran'], ['/hadith', 'Hadith'], ['/live', 'Live TV'], ['/tools', 'Free tools'], ['/tools/zakat-calculator', 'Zakat calculator'], ['/tools/linux-commands-cheat-sheet', 'Linux commands'], ['/reviews', 'Customer reviews'], ['/islamic', 'Islamic reminders'], ['/blog', 'Blog'], ['/privacy-policy', 'Privacy policy'], ['/terms', 'Terms of use']]} />
          <p className="mt-4 text-sm font-semibold text-cream">Get the app</p>
          <span className="mt-2 block text-sm"><InstallApp /></span>
          <p className="mt-1 text-xs text-faint">Tez khulta hai, weak internet par bhi chalta hai. Free.</p>
        </div>
      </div>
      <p className="mx-auto mt-8 max-w-7xl border-t border-line px-4 pt-5 text-xs text-faint">© {new Date().getFullYear()} Mizanora, {SITE.city}. {CREDIT}</p>
    </footer>
  );
}

function FooterCol({ title, links }) {
  return (
    <div>
      <h2 className="mb-3 font-sans text-sm font-semibold text-cream">{title}</h2>
      <ul className="space-y-2">
        {links.map(([href, label]) => <li key={href}><Link href={href} className="text-sm text-dim hover:text-gold">{label}</Link></li>)}
      </ul>
    </div>
  );
}
